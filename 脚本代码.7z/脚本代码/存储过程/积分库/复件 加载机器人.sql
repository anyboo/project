
----------------------------------------------------------------------------------------------------

--USE QPTreasureDB
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_GR_LoadAndroidUser]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_GR_LoadAndroidUser]
GO

SET QUOTED_IDENTIFIER ON 
GO

SET ANSI_NULLS ON 
GO
----------------
---20120307�޸����Ӽ��ػ����˵�ʱ���������
----------------------------------------------------------------------------------------------------

-- ���ػ�����
CREATE PROC GSP_GR_LoadAndroidUser
	@wKindID INT,								-- ��Ϸ I D
	@wServerID INT,								-- ���� I D
	@lMaxScore BIGINT,							--������
	@lMinScore	BIGINT							--���ٷ���
WITH ENCRYPTION AS

-- ��������
SET NOCOUNT ON

declare @UserID1 INT
Declare @UserID2 INT
DECLARE @lAndroidMax BIGINT
declare @lAndroidMin BIGINT
declare @lAndroidYunfen BIGINT

-- ���serviceload.ini 
set @lAndroidMax=@lMaxScore	--���ؽ�ȥ����Ϸ��߷�
SET @lAndroidMin=@lMinScore		--���ػ�������ͷ�
SET @lAndroidYunfen=@lMaxScore/2	--�߷ֻ����˸��ͷֻ����˵ķ�

if @lAndroidMax < 1000
begin
	set @lAndroidMax =100000000000000000
	set @lAndroidYunfen=5000000
	set  @lAndroidMin=100
end

-- ִ���߼�
BEGIN

	-- ������Ϣ
--	SELECT UserID FROM AndroidUserInfo WHERE KindID=@wKindID AND ServerID=@wServerID AND Nullity=0 ORDER BY NEWID()

	-- ������Ϣ
	select userid from GameScoreInfo where Score between @lAndroidMin and @lAndroidMax and userid in 
	(SELECT UserID FROM AndroidUserInfo WHERE KindID=@wKindID AND ServerID=@wServerID AND Nullity=0 )
	--ORDER BY NEWID()
--������Ϣ			���ӿ������е��û�
--	update  AndroidUserInfo set KindID=@wKindID,ServerID=@wServerID ,nullity=0
--		where userid in (select userid from selectfrom GameScoreInfo where Score between @lAndroidMin and @lAndroidMax and userid in 
--							(SELECT UserID FROM AndroidUserInfo WHERE Nullity=1 ))
--	--ȡ����Ϣ
--	update  AndroidUserInfo set nullity=1 where userid in
--			(select userid from QPTreasureDB.dbo.GameScoreInfo where Score <@lAndroidMin and userid in 
--				(select userid from QPTreasureDB.dbo.AndroidUserInfo where userid not in
--					(select userid from QPTreasureDB.dbo.GameScoreLocker ) and Nullity = 0 and  KindID=@wKindID
--				)
--			)
--	
	select top(1) @UserID1=userid from GameScoreInfo where Score > @lAndroidMax and userid in 
	(select userid from AndroidUserInfo where userid not in
	(select userid from QPTreasureDB.dbo.GameScoreLocker where serverid=@wServerID) and Nullity = 0 and  ServerID=@wServerID
	)

	select top(1) @UserID2=userid from GameScoreInfo where Score <@lAndroidMin and userid in 
	(select userid from AndroidUserInfo where userid not in
	(select userid from QPTreasureDB.dbo.GameScoreLocker  where serverid=@wServerID) and Nullity = 0 and  ServerID=@wServerID
	)

	if (@UserID2 is not null) and (@UserID1 is not null)
	begin
		update GameScoreInfo Set Score = (Score - @lAndroidYunfen) where userid = @UserID1
		update GameScoreInfo Set Score = (Score + @lAndroidYunfen) where userid = @UserID2
	end

END

RETURN 0

GO

----------------------------------------------------------------------------------------------------