

------------------------------------------------
--20120224 ����ת��˰�ռ�¼
------------------------------------------------
USE QPTreasureDB
GO

SET QUOTED_IDENTIFIER ON 
GO

SET ANSI_NULLS ON 
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_GR_TransferGameGold]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_GR_TransferGameGold]
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_GR_TransferGameGold]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_GR_TransferGameGold]
GO

-- �洢���
CREATE PROC GSP_GR_TransferGameGold
	@dwUserID INT,
	@dwTagGameID INT,
	@lSwapScore BIGINT,
	@lRevenue	BIGINT,
	@lCurrentScore BIGINT,
	@lCurrentBankScore BIGINT,
	@bIsOnline INT,
	@dwKindID INT,
	@dwServerID INT,
	@strClientIP NVARCHAR(15),
	@bIsGameIDTransfer INT,
	@szRecvName NVARCHAR(31)
WITH ENCRYPTION AS

-- ��������
SET NOCOUNT ON

DECLARE @SendUserInsureScore BIGINT
DECLARE @SendUserScore BIGINT
DECLARE @RecvUserInsureScore BIGINT
DECLARE @RecvUserScore BIGINT
declare @SourceGameID int
Declare @Score BIGINT
declare @InsureScore bigint 
DECLARE @RecvUserID INT
declare @TargetUserName nvarchar(31)
DECLARE @SourceAccounts NVARCHAR(31)

DECLARE @Nullity		TINYINT
DECLARE @StunDown		TINYINT

---- ִ���߼�
BEGIN

	set @bIsGameIDTransfer=1
	--GAMEIDת��
	IF @bIsGameIDTransfer = 1 
	BEGIN
		select @RecvUserID=UserID, @szRecvName=Accounts from QPGameUserDB.dbo.AccountsInfo(NOLOCK) WHERE GameID=@dwTagGameID
	END
	ELSE --�û���ת��
	BEGIN
		select @RecvUserID=UserID, @dwTagGameID = GameID from QPGameUserDB.dbo.AccountsInfo(NOLOCK) WHERE Accounts=@szRecvName
	END

	select @SourceAccounts=Accounts,@SourceGameID=GameID, @StunDown=StunDown from QPGameUserDB.dbo.AccountsInfo(NOLOCK) WHERE USERID = @dwUserID

	select @SendUserInsureScore=InsureScore, @SendUserScore=Score FROM GameScoreInfo WHERE USERID = @dwUserID

	IF @RecvUserID IS NULL
	BEGIN
		--ת��ʧ�ܼ�¼
--	  INSERT RecordInsure(KindID,ServerID,SourceUserID,TargetGameID,SendUserScore,SendUserInsureScore,SwapScore,RecvUserID,RecvUserScore, RecvUserInsureScore,ClientIP)
--	  VALUES (@dwKindID,@dwServerID,@dwUserID,@SendUserScore,@SendUserInsureScore,@lSwapScore,-9999,-9999999,-9999999,@strClientIP)
--		INSERT RecordInsure(KindID,ServerID,SourceUserID,SourceGameID,SourceAccounts,TargetGameID,TargetUserID,TargetAccounts,SourceUserScore,InsureScore, SwapScore,Revenue,TargetUserScore, TargetUserInsure,bIsOnline,ClientIP, TradeType)
--		values(@dwKindID,@dwServerID,@dwUserID,@SourceGameID, @SourceAccounts,@dwTagGameID,-1,@szRecvName,@lCurrentScore,@lCurrentBankScore, @lSwapScore,0,0,0,@bIsOnline,@strClientIP, 3)
--	INSERT INTO RecordInsure(KindID,ServerID,SourceUserID,SourceGold,SourceBank,TargetUserID,TargetGold,TargetBank,SwapScore,Revenue,IsGamePlaza,TradeType,ClientIP,CollectNote)
--	VALUES(@dwKindID,@dwServerID,@dwUserID,@SendUserScore,@SendUserInsureScore,0,0,0,@lSwapScore,0,0,3,@strClientIP,'ת��ʧ��')

		  	-- �������
		Set @RecvUserID = 0
		SELECT @dwUserID AS dwUserID, @dwTagGameID AS dwTagGameID, @bIsOnline AS bIsOnline,@lSwapScore AS lSwapScore,@lRevenue AS lRevenue, @szRecvName AS szRecvName
		return 1
	END

	select @RecvUserInsureScore=InsureScore, @RecvUserScore=Score FROM GameScoreInfo WHERE USERID = @RecvUserID
	
	if @RecvUserInsureScore is null
	begin
    	INSERT INTO GameScoreInfo (UserID, LastLogonIP, RegisterIP)	VALUES (@RecvUserID,@strClientIP,@strClientIP)
	end
	
	IF @bIsOnline=0
	BEGIN
		update GameScoreInfo Set InsureScore=InsureScore+@lSwapScore Where UserID=@RecvUserID
	END	

	select @Score=Score, @InsureScore=InsureScore  FROM GameScoreInfo WHERE USERID = @dwUserID
	select @RecvUserInsureScore=InsureScore, @RecvUserScore=Score FROM GameScoreInfo WHERE USERID = @RecvUserID

--����˰�ռ�¼
	update GameScoreInfo Set  Revenue=Revenue+@lRevenue where userid  =@RecvUserID 

	select @TargetUserName=Accounts from QPGameUserDB.dbo.AccountsInfo(NOLOCK) WHERE USERID = @RecvUserID 

--	INSERT RecordTransferGameGold(KindID,ServerID,SendUserID,SendUserScore,SendUserInsureScore,SwapScore,RecvUserID,RecvUserScore, RecvUserInsureScore,ClientIP)
--	VALUES (@dwKindID,@dwServerID,@dwUserID,@SendUserScore,@SendUserInsureScore,@lSwapScore, @RecvUserID,@RecvUserScore,@RecvUserInsureScore,@strClientIP)
--	INSERT RecordInsure(KindID,ServerID,SourceUserID,SourceGameID,SourceAccounts,TargetGameID,TargetUserID,TargetAccounts, SourceUserScore,InsureScore, SwapScore,Revenue,TargetUserScore, TargetUserInsure,bIsOnline,ClientIP, TradeType)
--	values(@dwKindID,@dwServerID,@dwUserID,@SourceGameID,@SourceAccounts,@dwTagGameID,@RecvUserID,@szRecvName,@lCurrentScore,@lCurrentBankScore, @lSwapScore,@lRevenue,@RecvUserScore,@RecvUserInsureScore,@bIsOnline,@strClientIP, 3)

	INSERT INTO RecordInsure(KindID,ServerID,SourceUserID,SourceUserName, SourceGold,SourceBank,TargetUserID,TargetUserName,TargetGold,TargetBank,SwapScore,Revenue,IsGamePlaza,TradeType,ClientIP,CollectNote)
	VALUES(@dwKindID,@dwServerID,@dwUserID,@SourceAccounts, @SendUserScore,@SendUserInsureScore,@RecvUserID,@TargetUserName,@RecvUserScore,@RecvUserInsureScore,@lSwapScore,@lRevenue,0,3,@strClientIP,'����')

		-- �������
	SELECT @dwUserID AS dwUserID, @dwTagGameID AS dwTagGameID, @bIsOnline AS bIsOnline,@lSwapScore AS lSwapScore, @lRevenue AS lRevenue, @szRecvName AS szRecvName

END
RETURN 0
GO
