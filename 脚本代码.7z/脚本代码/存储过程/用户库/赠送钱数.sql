
----------------------------------------------------------------------------------------------------

USE QPGameUserDB
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_GIVE_MONEY]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_GIVE_MONEY]
GO

----------------------------------------------------------------------------------------------------

-- �����û�
CREATE PROC GSP_GIVE_MONEY
	@dwUserID INT,								-- ��Ϸ I D
	@nType	 INT,								-- �������� 0���û��� 1���û�ID
	@strNickName NCHAR(32),						-- �û���
	@wGameID INT,								-- �û�ID
	@strClientIP NVARCHAR(15),
	@bQueryInfo INT,							--�Ƿ��ѯ�û���Ϣ
	@lScore BIGINT,								-- ���
	@lRevenue BIGINT								-- ˰��
WITH ENCRYPTION AS

declare @lSwapScore bigint
DECLARE @ErrorDescribe AS NVARCHAR(128)
DECLARE @UserID INT
DECLARE @UserID1 INT
DECLARE @UserScore BIGINT
DECLARE @Accounts NVARCHAR(32)
DECLARE @GiveScore BIGINT
DECLARE @SendUserScore BIGINT
DECLARE @RecvUserScore BIGINT
declare @SourceGameID int
declare @TargetUserName nvarchar(31)
DECLARE @SourceAccounts NVARCHAR(31)
Declare @TargetGameID INT

set @GiveScore=@lScore

-- ִ���߼�
BEGIN

	if @GiveScore <= 0
	begin
			SET @ErrorDescribe =  '����Ϊ����'
			SELECT [ErrorDescribe]=@ErrorDescribe
			return 1
	end

	select @SourceAccounts=Accounts,@SourceGameID=GameID from QPGameUserDB.dbo.AccountsInfo(NOLOCK) WHERE USERID = @dwUserID
	select @SendUserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo WHERE USERID = @dwUserID
	if @SendUserScore is null
	begin
		INSERT INTO QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo (UserID, LastLogonIP, RegisterIP)	VALUES (@UserID,@strClientIP,@strClientIP)
	end
	select  @SendUserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo WHERE USERID = @dwUserID

	IF @nType = 0
		BEGIN
			IF EXISTS (SELECT UserID FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreLocker WHERE UserID=@dwUserID)
			BEGIN
				SET @ErrorDescribe =  '������Ϸ�����ˣ����ܽ��д������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 1
			END
			
			SELECT @UserID=UserID FROM QPGameUserDBLink.QPGameUserDB.dbo.AccountsInfo where Accounts=@strNickName
			
			IF @UserID Is NULL
			BEGIN
				SET @ErrorDescribe =  '���͵��û��������ڣ���ȷ�Ϻ���������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 3
			END

			if @UserID=@dwUserID
			begin
				SET @ErrorDescribe =  '���ܸ��Լ�����'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 3
			end

			SELECT @UserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo where UserID=@dwUserID
			IF @UserScore<@GiveScore
			BEGIN
				SET @ErrorDescribe =  '������û����ô�໶�ֶ�����ȷ�Ϻ���������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				return 2
			END

			--����û������
			select  @RecvUserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo WHERE USERID = @UserID
			if @RecvUserScore is null
			begin
    			INSERT INTO QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo (UserID, LastLogonIP, RegisterIP)	VALUES (@UserID,@strClientIP,@strClientIP)
			end
			
			select @TargetUserName=Accounts,@TargetGameID=GameID from QPGameUserDBLink.QPGameUserDB.dbo.AccountsInfo WHERE USERID = @UserID
			select @RecvUserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo WHERE USERID = @UserID
	
			--��ѯ�û���Ϣ
			IF @bQueryInfo = 1
			begin
				set @lSwapScore = @lRevenue + @GiveScore
				SELECT @TargetUserName AS TargetAccount,@TargetGameID As TargetGameID, @lSwapScore  AS SwapScore 
				RETURN 10
			end

			update QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo set Score=Score-@GiveScore-@lRevenue where UserID=@dwUserID
			update QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo set Score=Score+@GiveScore where UserID=@UserID
			
		--	Insert QPGameUserDBLink.QPGameUserDB.dbo.GiveScoreRecord(UserID,GiveUserID,GiveScore,GiveType,Accounts)
		--	values(@dwUserID,@UserID,@GiveScore,0,@strNickName)

			INSERT INTO QPTreasureDBLink.QPTreasureDB.dbo.RecordInsure(KindID,ServerID,SourceUserID,SourceUserName, SourceGold,SourceBank,TargetUserID,TargetUserName,TargetGold,TargetBank,SwapScore,Revenue,IsGamePlaza,TradeType,ClientIP,CollectNote)
			VALUES(0,0,@dwUserID,@SourceAccounts, @SendUserScore,0,@UserID,@TargetUserName,@RecvUserScore,0,@GiveScore,@lRevenue,0,3,'0.0.0.0','����')

			return 0
			
		END
	ELSE IF @nType = 1
		BEGIN
			IF EXISTS (SELECT UserID FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreLocker WHERE UserID=@dwUserID)
			BEGIN
				SET @ErrorDescribe =  '������Ϸ�����ˣ����ܽ��д������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 1
			END
			
			SELECT @UserID1=UserID,@Accounts=Accounts FROM QPGameUserDBLink.QPGameUserDB.dbo.AccountsInfo where GameID=@wGameID
			
			--set @Accounts=rtrim(@Accounts)
			
			IF @UserID1 Is NULL
			BEGIN
				SET @ErrorDescribe =  '���͵��û�ID�����ڣ���ȷ�Ϻ���������'--+convert(nvarchar(15),@ftp)
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 3
			END

			SELECT @UserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo where UserID=@dwUserID
			IF @UserScore<@GiveScore
			BEGIN
				SET @ErrorDescribe =  '������û����ô�໶�ֶ�����ȷ�Ϻ���������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				return 2
			END
			
			select @RecvUserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo WHERE USERID = @UserID1
			if @RecvUserScore is null
			begin
    			INSERT INTO QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo(UserID, LastLogonIP, RegisterIP)	VALUES (@UserID,'0.0.0.0','0.0.0.0')
			end
			
			if @UserID1=@dwUserID
			begin
				SET @ErrorDescribe =  '���ܸ��Լ�����'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 3
			end

			select @TargetUserName=Accounts,@TargetGameID=GameID from QPGameUserDBLink.QPGameUserDB.dbo.AccountsInfo WHERE USERID = @UserID1
			select  @RecvUserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo WHERE USERID = @UserID1
	
			--��ѯ�û���Ϣ
			IF @bQueryInfo = 1
			begin
				set @lSwapScore = @lRevenue + @GiveScore
				SELECT @TargetUserName AS TargetAccount,@TargetGameID As TargetGameID , @lSwapScore AS SwapScore 
				RETURN 10
			end

			update QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo set Score=Score-@GiveScore-@lRevenue where UserID=@dwUserID
			update QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo set Score=Score+@GiveScore where UserID=@UserID1
			
--			Insert QPGameUserDBLink.QPGameUserDB.dbo.GiveScoreRecord(UserID,GiveUserID,GiveScore,GiveType,Accounts)
--			values(@dwUserID,@UserID1,@GiveScore,1,@Accounts)

			INSERT INTO QPTreasureDBLink.QPTreasureDB.dbo.RecordInsure(KindID,ServerID,SourceUserID,SourceUserName, SourceGold,SourceBank,TargetUserID,TargetUserName,TargetGold,TargetBank,SwapScore,Revenue,IsGamePlaza,TradeType,ClientIP,CollectNote)
			VALUES(0,0,@dwUserID,@SourceAccounts, @SendUserScore,0,@UserID1,@Accounts,@RecvUserScore,0,@GiveScore,@lRevenue,0,3,'0.0.0.0','����')

			return 0
		END

END

RETURN 0

GO

----------------------------------------------------------------------------------------------------