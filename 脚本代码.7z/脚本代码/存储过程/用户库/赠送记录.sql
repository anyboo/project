
----------------------------------------------------------------------------------------------------

USE QPGameUserDB
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_GIVE_RECORD]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_GIVE_RECORD]
GO

----------------------------------------------------------------------------------------------------

-- �����û�
CREATE PROC GSP_GIVE_RECORD
	@dwUserID INT							-- ��Ϸ I D
WITH ENCRYPTION AS


DECLARE @ErrorDescribe AS NVARCHAR(128)
DECLARE @InsurePass NCHAR(32)

-- ִ���߼�
BEGIN
	
	-- ��ѯ�û�
	select RecordID,SourceUserName, TargetUserName,SwapScore,TradeType,CollectDate from QPTreasureDBLink.QPTreasureDB.dbo.RecordInsure where (SourceUserID=@dwUserID or TargetUserID=@dwUserID ) and CollectDate>=GetDate()-7

END

RETURN 0

GO

----------------------------------------------------------------------------------------------------