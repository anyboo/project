
----------------------------------------------------------------------------------------------------

USE QPGameUserDB
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_USER_UNDERWRITE]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_USER_UNDERWRITE]
GO



----------------------------------------------------------------------------------------------------

-- �����û�
CREATE PROC GSP_USER_UNDERWRITE
	@dwUserID INT,								-- ��Ϸ I D
	@szUnderWrite NVARCHAR(32)						-- �û���
WITH ENCRYPTION AS


DECLARE @ErrorDescribe AS NVARCHAR(128)


-- ִ���߼�
BEGIN
	-- ��ѯ�û�
	update AccountsInfo set UnderWrite=@szUnderWrite where UserID=@dwUserID

END

RETURN 0

GO

----------------------------------------------------------------------------------------------------
