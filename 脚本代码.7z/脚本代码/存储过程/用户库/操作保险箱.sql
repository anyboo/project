
----------------------------------------------------------------------------------------------------

USE QPGameUserDB
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_OPER_MONEY]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_OPER_MONEY]
GO

----------------------------------------------------------------------------------------------------

-- �����û�
CREATE PROC GSP_OPER_MONEY
	@dwUserID INT,								-- ��Ϸ I D
	@nType	 INT,								-- �������� 0��SAVE 1��GET
	@dwKindID INT,								-- ����ID
	@lScore NCHAR(32)								-- ������¼
WITH ENCRYPTION AS

DECLARE @DbName NVARCHAR(32)
DECLARE @ErrorDescribe AS NVARCHAR(128)
DECLARE @UserScore BIGINT
DECLARE @UserScore1 BIGINT
declare @sql nvarchar(400)
DECLARE @GiveScore BIGINT
-- ִ���߼�
BEGIN
	IF @nType = 0
		BEGIN
			set @GiveScore=cast(@lScore as bigint)

			IF EXISTS (SELECT UserID FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreLocker WHERE UserID=@dwUserID)
			BEGIN
				SET @ErrorDescribe =  '������Ϸ�����ˣ����ܽ��д������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 1
			END
			
			SELECT @DbName=DataBaseName FROM QPServerInfoDBLink.QPServerInfoDB.dbo.GameKindItem where KindId=@dwKindID
			
			IF @DbName IS NULL
			BEGIN
				SET @ErrorDescribe =  '��ȡ���ֶ����䲻���ڡ���ȷ�Ϻ��ڲ���'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 2
			END
			
			set @sql = 'SELECT @UserScore=Score FROM '+ @DbName+'.Dbo.GameScoreInfo WHERE UserID='+convert(nvarchar(10),@dwUserID)
			exec sp_executesql @sql,N'@UserScore BIGINT output',@UserScore output
			
			IF @UserScore IS NULL
			BEGIN
				--INSERT INTO GameScoreInfo (UserID)	VALUES (@dwUserID)
				set @sql = 'INSERT INTO '+ @DbName+'.Dbo.GameScoreInfo (UserID,LastLogonIP, RegisterIP) VALUES ('+convert(nvarchar(10),@dwUserID)+', ''1.1.1.1'',''1.1.1.1'')'
				exec sp_executesql @sql
				
				SET @ErrorDescribe =  '����û����ô�໶�ֶ�����ȷ�Ϻ���������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				return 3
			END

			IF @UserScore<@GiveScore
			BEGIN
				SET @ErrorDescribe =  '����û����ô�໶�ֶ�����ȷ�Ϻ���������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				return 4
			END
			
			
			set @sql = 'update  '+ @DbName+'.Dbo.GameScoreInfo set Score=Score-'+convert(nvarchar(15),@GiveScore)+'where UserID='+convert(nvarchar(10),@dwUserID)
			exec sp_executesql @sql

				
			
			update QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo set Score=Score+@GiveScore where UserID=@dwUserID

			return 0
			
		END
	ELSE IF @nType = 1
		BEGIN
			set @GiveScore=cast(@lScore as bigint)

			IF EXISTS (SELECT UserID FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreLocker WHERE UserID=@dwUserID)
			BEGIN

				SET @ErrorDescribe =  '������Ϸ�����ˣ����ܽ��д������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 5
			END
			
			SELECT @UserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo where UserID=@dwUserID
			IF @UserScore<@GiveScore
			BEGIN
				SET @ErrorDescribe =  '������û����ô�໶�ֶ�����ȷ�Ϻ���������'
				SELECT [ErrorDescribe]=@ErrorDescribe
				return 6
			END

			SELECT @DbName=DataBaseName FROM QPServerInfoDBLink.QPServerInfoDB.dbo.GameKindItem where KindId=@dwKindID
			IF @DbName Is NULL
			BEGIN
				SET @ErrorDescribe =  '�������ֶ����䲻���ڡ���ȷ�Ϻ��ڲ���'
				SELECT [ErrorDescribe]=@ErrorDescribe
				RETURN 7
			END
					
			update QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo set Score=Score-@GiveScore where UserID=@dwUserID
			
			DECLARE @dwUserID1 INT			

			set @sql = 'SELECT @dwUserID1=UserID FROM '+ @DbName+'.Dbo.GameScoreInfo WHERE UserID='+convert(nvarchar(10),@dwUserID)
			exec sp_executesql @sql,N'@dwUserID1 BIGINT output',@dwUserID1 output

			
			
			IF @dwUserID1 IS NULL
			BEGIN
				set @sql = 'INSERT INTO '+ @DbName+'.Dbo.GameScoreInfo (UserID,LastLogonIP, RegisterIP) VALUES ('+convert(nvarchar(10),@dwUserID)+', ''1.1.1.1'',''1.1.1.1'')'
				exec sp_executesql @sql
			END
			
			set @sql = 'update  '+ @DbName+'.Dbo.GameScoreInfo set Score=Score+'+convert(nvarchar(15),@GiveScore)+'where UserID='+convert(nvarchar(10),@dwUserID)
			exec sp_executesql @sql
			
			return 0
		END
	ELSE
		BEGIN
			SELECT @UserScore=Score FROM QPTreasureDBLink.QPTreasureDB.dbo.GameScoreInfo where UserID=@dwUserID	
			
			SELECT @DbName=DataBaseName FROM QPServerInfoDBLink.QPServerInfoDB.dbo.GameKindItem where KindId=@dwKindID
		--	declare @sql2 nvarchar(400)
			IF @DbName Is NULL
				SET @UserScore1=0
			ELSE
			BEGIN
				set @sql = 'SELECT @UserScore1=Score FROM '+ @DbName+'.Dbo.GameScoreInfo WHERE UserID='+convert(nvarchar(10),@dwUserID)
				exec sp_executesql @sql,N'@UserScore1 bigint output',@UserScore1 output
			END
			
			SELECT @UserScore AS a, @UserScore1 AS b 
			return  0

		END

END

RETURN 0

GO

----------------------------------------------------------------------------------------------------