
----------------------------------------------------------------------------------------------------

USE QPGameUserDB
GO

IF EXISTS (SELECT * FROM DBO.SYSOBJECTS WHERE ID = OBJECT_ID(N'[dbo].[GSP_USER_INFO]') and OBJECTPROPERTY(ID, N'IsProcedure') = 1)
DROP PROCEDURE [dbo].[GSP_USER_INFO]
GO



----------------------------------------------------------------------------------------------------

-- �����û�
CREATE PROC GSP_USER_INFO
	@dwUserID INT,								-- ��Ϸ I D
	@szAddress NCHAR(64),						-- ��ַ
	@szSchool NCHAR(32),						-- ѧ��
	@szEmail NCHAR(32),							-- �ʼ�
	@szUrl NCHAR(32),							-- ��ҳ
	@szTel NCHAR(32),							-- �绰
	@szMsn NCHAR(32)							-- MSN
WITH ENCRYPTION AS


DECLARE @ErrorDescribe AS NVARCHAR(128)


-- ִ���߼�
BEGIN
	-- ��ѯ�û�
	--update AccountsInfo set C_ADDRESS=@szAddress,xueli=@szSchool,EMail=@szEmail,zhiye=@szUrl,Phone=@szTel,msn=@szMsn where UserID=@dwUserID


END

RETURN 0

GO

----------------------------------------------------------------------------------------------------
