declare @i int
set @i=1
declare @Id1 int
declare @Id2 int
declare @TempGameId1 int
declare @TempGameId2 int
while @i < 30000
begin
	select top (1) @Id1=abs(checksum(NEWID()))%30000+1 from dbo.sysobjects,dbo.syscolumns
	select top (1) @Id2=abs(checksum(NEWID()))%30000+1 from dbo.sysobjects,dbo.syscolumns
	--print str(@Id1)+'____'+str(@Id2)
	if @Id1 <> @Id2
	begin
		select @TempGameId1 = GameId from GameIdentifier where userid = @Id1
		select @TempGameId2 = GameId from GameIdentifier where userid = @Id2 
		--print str(@TempGameId1)+'__sdfsdf__'+str(@TempGameId2)
		if (@TempGameId1  IS NOT NULL ) and (@TempGameId2  IS NOT NULL ) and (@TempGameId2 <> @TempGameId1 )
		begin 
			update GameIdentifier set GameId = @TempGameId2 where userid = @Id1
			update GameIdentifier set GameId = @TempGameId1 where userid = @Id2
			--print @Id1
		end
	end
	set @i=@i+1
end